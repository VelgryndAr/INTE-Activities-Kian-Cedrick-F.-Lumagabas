
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
        int num1 = 30;
        int num2 = 25;
        System.out.println("=====Four Function Calculator=====");
        System.out.println("Addition: " + (num1 + num2));
        System.out.println("Subtraction: " + (num1 - num2));
        System.out.println("Multiplication: " + (num1 * num2));
        System.out.println("Division: " + (num1 / num2));
        System.out.println("Modulos: " + (num1 % num2));

        // I used positive numbers so none of the answers will be negative.
    }
}
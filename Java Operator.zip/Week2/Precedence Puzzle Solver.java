
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
        
        int a = 3, b = 5;
        boolean x = true, y = false;

        // Prediction: 18
        System.out.println("Expression 1: " + (a + b * 3));
        // Multiplication happens before addition.

        // Prediction: false
        System.out.println("Expression 2: " + (a > b && x || y));

        // Prediction: 9
        System.out.println("Expression 3: " + (++a + b));
    }


}

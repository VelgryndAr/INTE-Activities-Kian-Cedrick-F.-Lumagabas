
// Online IDE - Code Editor, Compiler, Interpreter


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        int number;
        int sum = 0;
        
        System.out.println("=====Add Until Sentinel Value=====");
        System.out.println("Enter numbers (-1 to stop):");

        number = input.nextInt();

        while (number != -1) {
            sum = sum + number;
            number = input.nextInt();
        }

        System.out.println("Total sum: " + sum);

        input.close();
    }
}

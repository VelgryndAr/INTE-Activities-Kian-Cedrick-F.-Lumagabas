
// Online IDE - Code Editor, Compiler, Interpreter
public class Main {
    public static void main(String[] args) {

        int size = 5;

        for (int i = 1; i <= size; i++) {

            // Skip printing row 3 using continue
            if (i == 3) {
                continue;
            }

            for (int j = 1; j <= size; j++) {

                // Stop printing when column 4 is reached in row 4
                if (i == 4 && j == 4) {
                    break;
                }

                System.out.print("* ");
            }

            System.out.println();
        }
    }
}

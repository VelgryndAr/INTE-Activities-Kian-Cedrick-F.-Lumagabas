
// Online IDE - Code Editor, Compiler, Interpreter


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // 2D array: -1 means the shelf is damaged
        int[][] inventory = {
            {10, 20, -1},
            {15, 25, 30},
            {5, -1, 40}
        };

        int choice;

        // Do-while loop for the menu
        do {
            System.out.println("\n=== WAREHOUSE INVENTORY ===");
            System.out.println("1. Display Inventory");
            System.out.println("2. Total Inventory");
            System.out.println("3. Find First Damaged Shelf");
            System.out.println("4. Restock Shelf");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");
            choice = input.nextInt();

            switch (choice) {

                case 1:
                    // Nested loops display the inventory
                    for (int i = 0; i < inventory.length; i++) {
                        for (int j = 0; j < inventory[i].length; j++) {

                            if (inventory[i][j] == -1) {
                                System.out.print("DAMAGED ");
                                continue; // Skip normal printing
                            }

                            System.out.print(inventory[i][j] + " ");
                        }
                        System.out.println();
                    }
                    break;

                case 2:
                    int total = 0;

                    // Count inventory but skip damaged shelves
                    for (int i = 0; i < inventory.length; i++) {
                        for (int j = 0; j < inventory[i].length; j++) {

                            if (inventory[i][j] == -1) {
                                continue;
                            }

                            total += inventory[i][j];
                        }
                    }

                    System.out.println("Total inventory: " + total);
                    break;

                case 3:
                    boolean found = false;

                    // Find the first damaged shelf
                    for (int i = 0; i < inventory.length; i++) {
                        for (int j = 0; j < inventory[i].length; j++) {

                            if (inventory[i][j] == -1) {
                                System.out.println(
                                    "First damaged shelf: Row "
                                    + (i + 1) + ", Column " + (j + 1)
                                );

                                found = true;
                                break; // Exit the inner loop
                            }
                        }

                        if (found) {
                            break; // Exit the outer loop too
                        }
                    }

                    if (!found) {
                        System.out.println("No damaged shelves found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter row (1-3): ");
                    int row = input.nextInt();

                    System.out.print("Enter column (1-3): ");
                    int col = input.nextInt();

                    // Validate the input
                    if (row < 1 || row > 3 || col < 1 || col > 3) {
                        System.out.println("Invalid shelf position.");
                        break;
                    }

                    // While loop simulates restocking
                    if (inventory[row - 1][col - 1] == -1) {
                        System.out.println("Cannot restock a damaged shelf.");
                    } else {
                        System.out.print("Enter quantity to add: ");
                        int quantity = input.nextInt();

                        while (quantity <= 0) {
                            System.out.print(
                                "Enter a quantity greater than 0: "
                            );
                            quantity = input.nextInt();
                        }

                        inventory[row - 1][col - 1] += quantity;

                        System.out.println("Shelf restocked successfully!");
                        System.out.println(
                            "New quantity: "
                            + inventory[row - 1][col - 1]
                        );
                    }
                    break;

                case 5:
                    System.out.println("Exiting inventory scanner...");
                    break;

                default:
                    System.out.println("Invalid choice. Try again.");
            }

        } while (choice != 5);

        input.close();
    }
}
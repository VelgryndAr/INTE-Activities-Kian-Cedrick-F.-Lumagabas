
// Online IDE - Code Editor, Compiler, Interpreter

public class Main {
    public static void main(String[] args) {
        System.out.println("===Number and Square Printer===");
        for (int num = 1; num <= 10; num++) {
            System.out.println("Number: " + num + " | Square: " + (num * num));
        }

    }
}

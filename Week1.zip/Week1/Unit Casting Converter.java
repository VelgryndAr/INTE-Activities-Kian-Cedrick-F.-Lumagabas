
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {

        double cenMeter = 550;
        int meter = (int) (cenMeter / 100);
        double remMeter = cenMeter - (meter * 100);

        System.out.println("=====Explicit Casting Converter=====");
        System.out.println("Centimeter: " + cenMeter);
        System.out.println("Whole Meter: " + meter);
        System.out.println("Remaining Meter: " + remMeter);

        int num = 70;

        //int automatically convert to double.
        //no cast is needed because double can store decimal value.
        double value = num;

        System.out.println("=====Implicit Widening=====");
        System.out.println(num);
        System.out.println(value);

        double value1 = 300.40;

        //double is converted to int.
        //the decimal part .40 is losing during the conversation.
        int num1 = (int) value1;

        System.out.println("=====Explicit Narrowing=====");
        System.out.println(value1);
        System.out.println(num1);

    }
}
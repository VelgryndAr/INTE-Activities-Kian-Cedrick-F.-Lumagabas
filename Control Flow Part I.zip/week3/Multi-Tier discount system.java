
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
        double amount = 2500;
        double rate;
        double discount;
        double price;
        String tier;

        if (amount < 1000) {
            rate = 0.0;
            tier = "0% Discount";
        } else if (amount < 3000) {
            rate = 0.05;
            tier = "5% Discount";
        } else if (amount < 5000) {
            rate = 0.10;
            tier = "10% Discount";
        } else {
            rate = 0.15;
            tier= "15% Discount";
        }

        discount = amount * rate;
        price = amount - discount;
        
        System.out.println("=====Multi-Tier Discount System=====");
        System.out.println("Purchase Amount: " + amount);
        System.out.println("Discount Tier: " + tier);
        System.out.println("Discount Amount: " + discount);
        System.out.println("Final Price: " + price);
        
        }
}

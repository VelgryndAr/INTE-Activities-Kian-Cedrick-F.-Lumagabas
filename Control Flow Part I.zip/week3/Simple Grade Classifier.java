
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
        int score = 92;
        System.out.println("=====Passed Grade=====");
        if (score >= 60) {
            System.out.println("Your Score: " + score);
            System.out.println("You Passed Congratulations!!!");
        } else {
            System.out.println("Your Score: " + score);
            System.out.println("You Fail Study Harder Next Time.");
        }
        System.out.println();
        score = 58;
        System.out.println("=====Failed Grade=====");
        if (score >= 60) {
            System.out.println ("Your Score: " + score);
            System.out.println("You Passed Congratulations!!!");
        } else {
            System.out.println("Your Score: " + score);
            System.out.println("You Fail Study Harder Next Time.");
        }
        
    }
}

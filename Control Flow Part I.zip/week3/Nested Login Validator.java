
// Online IDE - Code Editor, Compiler, Interpreter

public class Main
{
    public static void main(String[] args) {
        
        String username = "admin";
        String password = "1234";
        boolean accountLocked = false;

        // First login test: correct details
        if (username.equals("admin")) {
            if (password.equals("1234")) {
                if (!accountLocked) {
                    System.out.println("=====Login Successfully=====");
                    System.out.println("Account Login Successfully");
                    System.out.println("Your Username:" + username);
                    System.out.println("Your Password: " + password);
                    System.out.println("Login successful!");
                    System.out.println("Welcome Back Admin.");
                    System.out.println();
                } else {
                    System.out.println("Login failed: Account is locked.");
                }
            } else {
                System.out.println("Login failed: Incorrect password.");
            }
        } else {
            System.out.println("Login failed: Incorrect username.");
        }

        // Second login test: incorrect password
        username = "admin";
        password = "4321";

        if (username.equals("admin")) {
            if (password.equals("1234")) {
                if (!accountLocked) {
                    System.out.println("Login successfull");
                    
                } else {
                    System.out.println("Login failed: Account is locked.");
                }
            } else {
                System.out.println("=====Login Failed=====");
                System.out.println("Your Username: " + username);
                System.out.println("Your Password: " + password);
                System.out.println("Login failed: Incorrect password.");
            }
        } else {
            System.out.println("Login failed: Incorrect username.");
        }
    }
}

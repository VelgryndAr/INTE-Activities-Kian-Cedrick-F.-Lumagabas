
// Online IDE - Code Editor, Compiler, Interpreter


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter username: ");
        String name = input.nextLine();

        System.out.print("Enter 4-digit PIN: ");
        int pin = input.nextInt();

        if (name.equals("admin")) {
            if (pin == 1234) {

                System.out.print("Enter balance: ");
                double balance = input.nextDouble();

                System.out.print("Enter withdrawal amount: ");
                double amount = input.nextDouble();

                System.out.print("Enter amount already withdrawn today: ");
                double withdrawn = input.nextDouble();

                System.out.print("Account tier (1-Bronze, 2-Silver, 3-Gold): ");
                int tier = input.nextInt();

                double rate = 0;

                switch (tier) {
                    case 1:
                        rate = 0.03;
                        break;
                    case 2:
                        rate = 0.02;
                        break;
                    case 3:
                        rate = 0.01;
                        break;
                    default:
                        System.out.println("DENIED: Invalid account tier.");
                        input.close();
                        return;
                }

                double fee = amount * rate;
                double total = amount + fee;

                if (amount <= balance) {
                    if (withdrawn + amount <= 5000) {
                        if (total <= balance) {
                            System.out.println("APPROVED");
                            System.out.println("Withdrawal: " + amount);
                            System.out.println("Fee: " + fee);
                            System.out.println("Total: " + total);
                        } else {
                            System.out.println("DENIED: Insufficient balance for fee.");
                        }
                    } else {
                        System.out.println("DENIED: Daily withdrawal limit exceeded.");
                    }
                } else {
                    System.out.println("DENIED: Insufficient balance.");
                }

            } else {
                System.out.println("DENIED: Incorrect PIN.");
            }
        } else {
            System.out.println("DENIED: Incorrect username.");
        }

        input.close();
    }
}

// Online IDE - Code Editor, Compiler, Interpreter

public class Main {
    public static void main(String[] args) {

        String[] favorites = {
            "Gaming",
            "Music",
            "Food",
            "Sleeping",
            "Reading"
        };
       
       System.out.println("=====Favourite Things Array=====");
        for (int i = 0; i < favorites.length; i++) {
            System.out.println((i + 1) + ". " + favorites[i]);
        }

        System.out.println("Total length: " + favorites.length);
    }
}

// Online IDE - Code Editor, Compiler, Interpreter
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // List of scores that will be checked and arranged
        int[] scores = {82, 74, 91, 67, 98, 79, 86, 93, 71, 88};

        System.out.println("Original Scores: " + Arrays.toString(scores));

        // Ask the user which score they want to find
        System.out.print("Enter a score to search for: ");
        int target = scanner.nextInt();

        int foundIndex = -1;

        // Compare the target with each score in the array
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] == target) {
                foundIndex = i;
                break;
            }
        }

        if (foundIndex != -1) {
            System.out.println("Score " + target + " was found at index " + foundIndex + ".");
        } else {
            System.out.println("Score " + target + " was not found.");
        }

        // Create a separate version of the scores for sorting
        int[] sortedScores = Arrays.copyOf(scores, scores.length);

        // Arrange the duplicate array from smallest to largest
        Arrays.sort(sortedScores);
        
        System.out.println("=====Search And Sort Mini-Tool=====");
        System.out.println("Original Scores: " + Arrays.toString(scores));
        System.out.println("Sorted Scores:   " + Arrays.toString(sortedScores));

        /*
         * The duplicate array is sorted so that the original
         * list remains in its starting order for future use.
         */

        scanner.close();
    }
}

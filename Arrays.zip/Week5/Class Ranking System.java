
// Online IDE - Code Editor, Compiler, Interpreter


public class Main {

    static class Student {
        String name;
        int[] quizzes;

        Student(String name, int[] quizzes) {
            this.name = name;
            this.quizzes = quizzes;
        }

        // Find the average of the student's quiz scores
        double getAverage() {
            int total = 0;

            for (int score : quizzes) {
                total += score;
            }

            return (double) total / quizzes.length;
        }
    }

    // Search through the students one at a time
    static int searchStudent(Student[] students, String name) {

        for (int i = 0; i < students.length; i++) {

            if (students[i].name.equalsIgnoreCase(name)) {
                return i;
            }
        }

        return -1;
    }

    // Sort students from highest average to lowest average
    static void rankStudents(Student[] students) {

        for (int i = 0; i < students.length - 1; i++) {

            int highest = i;

            for (int j = i + 1; j < students.length; j++) {

                if (students[j].getAverage() > students[highest].getAverage()) {
                    highest = j;
                }
            }

            Student temp = students[i];
            students[i] = students[highest];
            students[highest] = temp;
        }
    }

    public static void main(String[] args) {

        int[][] quizData = {
            {86, 90, 84, 88},
            {75, 81, 79, 83},
            {95, 91, 93, 97},
            {82, 85, 80, 87},
            {89, 94, 91, 90}
        };

        Student[] students = {
            new Student("Angelo", quizData[0]),
            new Student("Kian", quizData[1]),
            new Student("Cris", quizData[2]),
            new Student("Jahzeel", quizData[3]),
            new Student("Jeric", quizData[4])
        };

        rankStudents(students);

        System.out.println("=================================");
        System.out.println("        CLASS RANKING SYSTEM");
        System.out.println("=================================");

        System.out.printf("%-8s %-12s %-10s%n",
                "Rank", "Name", "Average");

        System.out.println("---------------------------------");

        for (int i = 0; i < students.length; i++) {

            System.out.printf("%-8d %-12s %.2f%n",
                    i + 1,
                    students[i].name,
                    students[i].getAverage());
        }

        System.out.println("---------------------------------");

        // Look for a particular student
        String searchName = "Cris";

        int result = searchStudent(students, searchName);

        if (result != -1) {
            System.out.println(searchName + " is ranked #" + (result + 1));
        } else {
            System.out.println(searchName + " was not found.");
        }

        // Display students ranked from 2nd to 4th
        System.out.println("\nStudents between rank 2 and rank 4:");

        for (int i = 1; i < 4; i++) {

            System.out.printf("%d. %s - %.2f%n",
                    i + 1,
                    students[i].name,
                    students[i].getAverage());
        }
    }
}


